# Muk Post // ViewSonic ColorPro 2026 Node Tree & Timeline Kit
**Created by Jackson McMurdo / Muk Post (@mukpost)**
Compatible with DaVinci Resolve 18.5, 19, and 20 (Free & Studio versions)

---

## ⚡️ WHAT'S INCLUDED IN THIS KIT:

1. **MukPost_ColorPro_Balance_10Node_Template.drp**
   - Standalone DaVinci Resolve Project containing both vertical (9:16) and horizontal (16:9) master sequences.
   - Simply double-click to open or go to Project Manager > Right Click > Restore Project Archive.

2. **Timelines/**
   - `ColorPro_Submission_Reel_13s_Vertical_9x16.drt`: Native 1080x1920 mobile reels timeline with all progressive cuts.
   - `ColorPro_Submission_13s_Horizontal_16x9.drt`: Native 1920x1080 uncropped widescreen timeline.
   - *How to import:* In any open Resolve project, choose **File > Import > Timeline...** and select either `.drt` file.

3. **PowerGrades/**
   - `MukPost_Iceland_10Node_LinearWB.drx`: Standalone 10-node scene-referred DWG grading tree.
   - `MukPost_Iceland_10Node_LinearWB.png`: Matching gallery preview still.
   - *How to import:* Open the **Color Page**, display the **Gallery**, right-click inside your PowerGrade album, click **Import...**, and choose this `.drx`. Right-click on any clip and choose **Apply Grade**.

4. **MukPost_10Node_DWG_Pipeline_Cheatsheet.jpg**
   - Complete 12-state visual breakdown showing how each node shapes the image.

---

## 🛠️ THE 10-NODE DWG ARCHITECTURE:

- **Node 01: CST IN** (Camera Raw -> DaVinci Wide Gamut / DaVinci Intermediate)
- **Node 02: EXPOSURE** (Primary Offset level in wide latitude space)
- **Node 03: CONTRAST** (Clean tonal pivot & S-curve)
- **Node 04: LINEAR WHITE BALANCE** (Gamma set to Linear, adjusted via Gain for mathematically pure neutral balance)
- **Node 05: SATURATION** (ColorSlice / chrominance enhancement)
- **Node 06: CONTRAST & SHARPNESS** (Micro-contrast and high-frequency roll-off)
- **Node 07: ONE NODE LOOK** (Creative split-tone highlight & shadow shaping)
- **Node 08: 35MM FILM GRAIN** (Organic 35mm print texture)
- **Node 09: CST OUT** (DaVinci Wide Gamut -> Rec.709 / Gamma 2.4)
- **Node 10: TIMELINE / POST-LOOK** (Master clamp and final safety ceiling)

---

## 📩 CONNECT & SUPPORT

- **Instagram:** [@mukpost](https://instagram.com/mukpost)
- **Website & Studio Finishing:** [mukpost.com](https://mukpost.com)
- **Questions or Client Inquiries:** contact@mukpost.com

Happy Grading!  
Jackson McMurdo // Muk Post
