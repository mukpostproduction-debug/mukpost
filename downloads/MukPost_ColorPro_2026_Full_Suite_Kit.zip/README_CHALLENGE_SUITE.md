# Muk Post // ViewSonic ColorPro 2026 Challenge Suite
## Complete Studio Grading Kits (Shots 01 & 02)

Official Muk Post multi-shot color grading kit for the ViewSonic ColorPro 2026 Challenge.

### 📦 Included Shots:
1. **Shot 01: Iceland Canyon & Falls** (Denis Barbas Drone Shot 3)
   - 1080×1920 (9:16) & 1920×1080 (16:9) DRT Timelines (13.0s master)
   - 10-Node PowerGrade (.drx) & Gallery Still
   - High-Res Covers & 12-Step Contact Sheet
2. **Shot 02: Active Volcano Caldera** (Denis Barbas Drone Shot 1)
   - 1080×1920 (9:16) & 1920×1080 (16:9) DRT Timelines (13.0s master)
   - 10-Node PowerGrade (.drx) & Gallery Still
   - High-Res Covers & 12-Step Contact Sheet

### ⚠️ Studio & Plugin Disclaimers:
- Requires DaVinci Resolve Studio (Paid Version)
- Third-party OFX plugins used: Alex Tech Magic Grade (Grain) & Node Mills Lens Node (Optics). Bypass them to use the 8 native DWG nodes freely.

Visit https://mukpost.com/balance for project updates and upcoming shot drops.
