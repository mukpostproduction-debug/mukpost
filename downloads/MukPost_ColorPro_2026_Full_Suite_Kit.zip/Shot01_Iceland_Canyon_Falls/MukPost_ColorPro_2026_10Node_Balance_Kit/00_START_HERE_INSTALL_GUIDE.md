# Muk Post // ViewSonic ColorPro 2026 Node Tree & Timeline Kit
**Created by Jackson McMurdo / Muk Post (@mukpost)**

---

## ⚠️ CRITICAL COMPATIBILITY & OFX PLUGIN NOTICE:

1. **DaVinci Resolve Studio (Paid Version) Required:**
   - This project archive (.drp) and PowerGrade tree (.drx) were built in **DaVinci Resolve Studio**.
   - They will **NOT open or function properly in the Free version** of DaVinci Resolve.

2. **Paid Third-Party OFX Plugins Used on Nodes 06 & 08:**
   - **Node 06 (Lens Node):** *Node Mills — Lens Node* (Optical aberration, halation, and roll-off).
   - **Node 08 (Film Grain):** *Alex Tech — Magic Grade Film* (Organic 35mm print grain and halation).
   - *Note:* These two plugins are commercial paid products. If you do not own them, Nodes 06 and 08 will show an offline OFX indicator.

3. **How to Grade Without These Plugins:**
   - Simply **bypass / disable Node 06 and Node 08** (Ctrl+D / Cmd+D on each node).
   - The remaining **8 core nodes** (Linear Gamma White Balance, Log to Rec.709 CSTs, Primary Exposure, Contrast S-curve, ColorSlice Saturation, and One-Node Look) use **100% native DaVinci Resolve Studio tools** and will work flawlessly!

---

## ⚡️ WHAT'S INCLUDED IN THIS KIT:

1. **MukPost_ColorPro_Balance_10Node_Template.drp**
   - Standalone DaVinci Resolve Studio Project containing both vertical (9:16) and horizontal (16:9) master sequences.
   - Simply double-click to open or go to Project Manager > Right Click > Restore Project Archive.

2. **Timelines/**
   - : Native 1080x1920 mobile reels timeline with all progressive cuts.
   - : Native 1920x1080 uncropped widescreen timeline.
   - *How to import:* In any open Resolve project, choose **File > Import > Timeline...** and select either  file.

3. **PowerGrades/**
   - : Standalone 10-node scene-referred DWG grading tree.
   - : Companion thumbnail for the DaVinci Resolve Gallery.
   - *How to import:* Open the **Color Page**, display the **Gallery**, right-click inside your PowerGrade album, click **Import...**, and choose this . Right-click on any clip and choose **Apply Grade**.

4. **MukPost_10Node_DWG_Pipeline_Cheatsheet.jpg**
   - Complete 12-state visual breakdown showing how each node shapes the image.

---

## 🛠️ THE 10-NODE DWG ARCHITECTURE:

- **Node 01: CST IN** (Camera Raw -> DaVinci Wide Gamut / DaVinci Intermediate) [Native]
- **Node 02: EXPOSURE** (Primary Offset level in wide latitude space) [Native]
- **Node 03: CONTRAST** (Clean tonal pivot & S-curve) [Native]
- **Node 04: LINEAR WHITE BALANCE** (Gamma set to Linear, adjusted via Gain for mathematically pure neutral balance) [Native]
- **Node 05: SATURATION** (ColorSlice / chrominance enhancement) [Native]
- **Node 06: SHARPNESS & LENS** (*Node Mills Lens Node* - Paid OFX Plugin)
- **Node 07: ONE NODE LOOK** (Creative split-tone highlight & shadow shaping) [Native]
- **Node 08: 35MM FILM GRAIN** (*Alex Tech Magic Grade Film* - Paid OFX Plugin)
- **Node 09: CST OUT** (DaVinci Wide Gamut -> Rec.709 / Gamma 2.4) [Native]
- **Node 10: TIMELINE / POST-LOOK** (Master clamp and final safety ceiling) [Native]

---

## 📩 CONNECT & SUPPORT

- **Instagram:** [@mukpost](https://instagram.com/mukpost)
- **Website & Studio Finishing:** [mukpost.com](https://mukpost.com)
- **Questions or Client Inquiries:** contact@mukpost.com

Happy Grading!  
Jackson McMurdo // Muk Post
