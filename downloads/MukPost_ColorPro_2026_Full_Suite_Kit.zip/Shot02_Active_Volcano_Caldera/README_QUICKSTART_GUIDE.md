# Muk Post // ViewSonic ColorPro 2026 Challenge
## Shot 01: Denis Barbas Active Volcano Eruption (10-Node DWG Pipeline)

Welcome to the official Muk Post studio grading kit for Shot 1 of the ViewSonic ColorPro 2026 Challenge.

---

### 📦 Kit Contents
1. **Timelines/**:
   - : 1080×1920 edge-to-edge mobile vertical master timeline (390 frames @ 29.97 fps) with progressive node reveals and outro slate.
   - : 1920×1080 widescreen cinema landscape timeline (390 frames @ 29.97 fps).
2. **PowerGrades/**:
   - : Complete 10-node DaVinci Wide Gamut / Intermediate studio grade ready for gallery import.
3. **Stills/**:
   - High-resolution covers (16:9 widescreen, 9:16 vertical reel) and 12-step sequential contact sheet.

---

### ⚠️ Compatibility & Required Software
- **DaVinci Resolve Studio (Paid Version):**
  Created inside DaVinci Resolve Studio. Free versions may not support all features or project files.
- **Commercial Third-Party OFX Plugins (Nodes 08 & 09):**
  - **Node 08 (OFX):** *Alex Tech — Magic Grade Film* (35mm grain profile)
  - **Node 09 (OFX):** *Node Mills — Lens Node* (Optical halation & chromatic dispersion)
  - *Note:* If you do not own these paid plugins, simply bypass Nodes 08 & 09. The core 8 nodes (Linear Gamma WB, Exposure, Contrast, Saturation, Sharpness, CSTs) are 100% native DaVinci Resolve tools.

---

### 🚀 Quickstart Import Instructions
1. Open your DaVinci Resolve Studio project.
2. In the **Color Page**, right-click in your **Gallery** and choose **Import...**.
3. Select .
4. Drag or middle-click the PowerGrade onto your raw camera footage!

Created with precision by **Muk Post** (https://mukpost.com/balance)
