# Muk Post // ViewSonic ColorPro 2026 Master Submission Suite
## Complete 6-Timeline & 4-Grade Studio Package

Professional DaVinci Resolve Studio grading collection by Muk Post (https://mukpost.com/balance).

---

### Package Contents:

#### 1. 01_All_6_DaVinci_Resolve_Timelines/ (.drt)
- : 1080×1920 mobile vertical reel (390 frames @ 29.97 fps)
- : 1920×1080 widescreen cinema landscape (390 frames @ 29.97 fps)
- : 1080×1920 mobile vertical reel (390 frames @ 29.97 fps)
- : 1920×1080 widescreen cinema landscape (390 frames @ 29.97 fps)
- : 1080×1920 mobile vertical reel (390 frames @ 29.97 fps)
- : 1080×1920 mobile vertical reel (390 frames @ 29.97 fps)

#### 2. 02_Master_10Node_PowerGrades/ (.drx)
- 
- 
- 
- 

#### 3. 03_Sequential_12Step_Contact_Sheets/ (.jpg)
- High-resolution 12-frame contact sheets for all four challenge footage submissions.

---

### Quickstart Guide:
1. Open DaVinci Resolve Studio.
2. Go to **File → Import → Timeline...** and select any of the 6  timelines.
3. In the **Color Page**, right-click in your Gallery and select **Import...** to import any  PowerGrade.

*Note: Built with DaVinci Resolve Studio. Third-party OFX plugins (Alex Tech Magic Grade Film grain, Node Mills Lens Node) on nodes 08/09 can be bypassed if you do not own them.*

Muk Post Studio // https://mukpost.com/balance
