# Muk Post // ViewSonic ColorPro 2026 Master Submission Suite
## The Complete 4-Shot DaVinci Wide Gamut / Intermediate Grade Collection

Welcome to the complete Muk Post professional grade package for the ViewSonic ColorPro 2026 Challenge.

---

### 📦 Collection Contents:
1. **01_Iceland_Canyon_Falls** (Denis Barbas Footage)
   - Vertical (9:16) & Horizontal (16:9) DaVinci Resolve Timelines (.drt)
   - 10-Node Master PowerGrade (.drx)
   - Master 12-Step Contact Sheet & Still Covers
2. **02_Volcano_Caldera_Eruption** (Denis Barbas Footage)
   - Vertical (9:16) & Horizontal (16:9) DaVinci Resolve Timelines (.drt)
   - 10-Node Master PowerGrade (.drx)
   - Master 12-Step Contact Sheet & Still Covers
3. **03_Reine_Norway_Ronald_Soethje** (Ronald Soethje Footage)
   - Vertical (9:16) DaVinci Resolve Timeline (.drt)
   - 10-Node Master PowerGrade (.drx)
   - Master 12-Step Contact Sheet & Still Covers
4. **04_Mountain_Coast_Ronald_Soethje** (Ronald Soethje Footage)
   - Vertical (9:16) DaVinci Resolve Timeline (.drt)
   - 10-Node Master PowerGrade (.drx)
   - Master 12-Step Contact Sheet & Still Covers

---

### ⚠️ Plugin & Compatibility Notice
- **DaVinci Resolve Studio (Paid Version):**
  This suite was mastered inside DaVinci Resolve Studio.
- **Third-Party Commercial Plugins (Bypassable):**
  - **Node 08:** *Alex Tech — Magic Grade Film* (35mm grain)
  - **Node 09:** *Node Mills — Lens Node* (Optical halation & dispersion)
  - *If you do not own these paid plugins, simply leave Nodes 08 and 09 disabled.* The core 8 nodes (Linear Gamma WB, Exposure, Contrast, Saturation, Sharpness, CSTs) are 100% native DaVinci Resolve tools.

Muk Post Studio // https://mukpost.com/balance
